import java.nio.file.Path;
import java.util.Base64;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public class HttpUtils {

    public static Request readRequestFromInputStream(InputStream inputStream) {
        String[] clientRequestParameters = new String[0];
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
            clientRequestParameters = in.readLine().split(" ");
        } catch (NullPointerException e) {
            System.err.println("Не удалось прочитать запрос клиента, метод чтения из входного потока in.readline() вернул null");
            e.printStackTrace();
        } catch (Exception e){
            System.err.println("Другая ошибка чтения входных параметров от клиента");
            e.printStackTrace();
        }
        System.out.println(Arrays.toString(clientRequestParameters));

        return new Request(clientRequestParameters[0], clientRequestParameters[1], clientRequestParameters[2]);

    }

    public static void sendResponse(Response response, File requestedFile, OutputStream outputStream) {
        try {
            outputStream.write(response.getResponse().getBytes());
            outputStream.write("\r\n\r\n".getBytes());
            if (requestedFile.getAbsolutePath().endsWith("png")) {
                String base64Img = Base64.getEncoder().encodeToString(Files.readAllBytes(Path.of(requestedFile.getAbsolutePath())));
                String imageHtmlCode = "<img src=\"data:image/png;base64," + base64Img + "\">";
                outputStream.write(imageHtmlCode.getBytes());
            } else {
                outputStream.write(Files.readAllBytes(Paths.get(requestedFile.getAbsolutePath())));
            }
            outputStream.flush();
        } catch (IOException e) {
            System.err.println("Не могу отправить запрос");
            e.printStackTrace();
        }
    }

    public static void sendResponse(Response response, OutputStream outputStream) {
        try {
            outputStream.write(response.getResponse().getBytes());
            outputStream.flush();
        } catch (IOException e) {
            System.err.println("Не могу отправить запрос");
            e.printStackTrace();
        }
    }

}
