public class Request {

    private final String method;
    private final String resource;
    private final String protocolVersion;

    public Request(String method, String resource, String protocolVersion) {
        this.resource = resource;
        this.method = method;
        this.protocolVersion = protocolVersion;
    }

    public String getResource() {
        return resource;
    }
    public String getMethod() {
        return method;
    }
    public String getProtocolVersion() {
        return protocolVersion;
    }

}
