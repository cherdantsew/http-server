import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Main {

    public static final String C_RESOURCES = "C:\\Users\\nvson\\IdeaProjects\\http-server\\src\\main\\resources";
    public static final String HOME_PAGE_ADDRESS = "\\index.html";
    public static final int FILE_NOT_FOUND_CODE = 404;
    public static final int REQUEST_SUCCEEDED_CODE = 200;

    public static void main(String[] args) {

        Socket clientSocket;

        try {
            ServerSocket serverSocket = new ServerSocket(1234);
            while (true) {
                clientSocket = serverSocket.accept();
                handleRequest(clientSocket);
                clientSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleRequest(Socket clientSocket) {

        Request request;
        Response response;
        File requestedFile;

        try {
            request = HttpUtils.readRequestFromInputStream(clientSocket.getInputStream());

            String requestedResource = request.getResource().replace('/', '\\');

            if ("\\".equals(requestedResource)) {
                requestedFile = new File(C_RESOURCES + HOME_PAGE_ADDRESS);
            } else requestedFile = new File(C_RESOURCES + requestedResource);

            if (!requestedFile.isFile()) {
                HttpUtils.sendResponse(new Response(request.getProtocolVersion(), FILE_NOT_FOUND_CODE, "Requested resource wasn't found on server"), clientSocket.getOutputStream());
                return;
            }

            response = new Response(request.getProtocolVersion(), REQUEST_SUCCEEDED_CODE, "OK");
            response.setHeader("Content-type", "text/html");

            HttpUtils.sendResponse(response, requestedFile, clientSocket.getOutputStream());

        } catch (IOException e) {
            System.err.println("Something went wrong");
            e.printStackTrace();
        }
    }
}