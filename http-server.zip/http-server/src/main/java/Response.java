
public class Response {

    private final String versionOfProtocol;
    private final int statusCode;
    private final String statusMessage;

    private StringBuilder header;


    public Response(String versionOfProtocol, int statusCode, String statusMessage) {
        this.versionOfProtocol = versionOfProtocol;
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;
    }


    public void setHeader(String headerName, String value) {
        this.header = new StringBuilder();
        header.append(headerName).append(": ").append(value).append("\n");
    }


    public String getResponse() {
        StringBuilder response = new StringBuilder();

        if (header != null)
            return response.append(versionOfProtocol).append(" ").append(statusCode).append(" ").append(statusMessage)
                    .append("\n")
                    .append(header).toString();
        else
            return response.append(versionOfProtocol).append(" ").append(statusCode).append(" ").append(statusMessage).toString();
    }
}
